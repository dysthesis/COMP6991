fn main() {
    for i in 1..=5 {
        println!("{i}");
    }
}
